let name = "Nithin"

let a = `
aqasdfdgfbgnh
${name}
dsdsdsdsdsd
`;
console.log(a)